package com.example.simplecaluculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
       private lateinit var n1f:EditText
       private lateinit var n2f:EditText
       private lateinit var resf:EditText

       fun operate(op:Int){
           val n1s=n1f.text.toString()
           val n2s =n2f.text.toString()
           var n3=0.0
           if(n1s.isEmpty() || n2s.isEmpty()){
               Toast.makeText(this,"One field is empty",Toast.LENGTH_SHORT)
           }else{
               val n1=n1s.toDouble()
               val n2=n2s.toDouble()
               when(op){
                   1->n3=n1+n2
                   2->n3=n1-n2
                   3->n3=n1/n2
                   4->n3=n1*n2
                   else-> Toast.makeText(this, "Unrecognized function", Toast.LENGTH_SHORT).show()

               }
               if (n3.isNaN()){

               }else{
                   resf.setText(n3.toString())
               }
           }
       }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        n1f=findViewById(R.id.editTextText5)
        n2f=findViewById(R.id.editTextText6)
        resf=findViewById(R.id.editTextText7)

        var op=0
        val addButton=findViewById<Button>(R.id.AddButton)
        addButton.setOnClickListener{
            op=1
            operate(op)
        }
        val subButton=findViewById<Button>(R.id.SubButton)
        subButton.setOnClickListener{
            op=2
            operate(op)
        }
        val divButton=findViewById<Button>(R.id.DivButton)
        divButton.setOnClickListener{
            op=3
            operate(op)
        }
        val mulButton=findViewById<Button>(R.id.MulButton)
        mulButton.setOnClickListener{
            op=4
            operate(op)
        }
        
    }


}
package com.example.fragments

import androidx.lifecycle.ViewModel

class Fragment1ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
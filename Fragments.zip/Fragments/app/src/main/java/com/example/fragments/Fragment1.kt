package com.example.fragments

import android.annotation.SuppressLint
import androidx.fragment.app.viewModels
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class Fragment1 : Fragment() {

    companion object {
        fun newInstance() = Fragment1()
    }

    private val viewModel: Fragment1ViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // TODO: Use the ViewModel
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        Log.d("FragmentLog","Fragment 1 added")
        var count=arguments?.getString("count").toString()
        if(count.isEmpty()){
            count="0"
        }
        val view= inflater.inflate(R.layout.fragment_fragment1, container, false)
        view.findViewById<TextView>(R.id.tv).setText("Fragment 1 :$count")
        return view
    }



}
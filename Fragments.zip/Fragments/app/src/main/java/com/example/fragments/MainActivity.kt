package com.example.fragments

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private var counter1 = 0
    private var counter2 = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.b1).setOnClickListener {
            counter1++
            val bund = Bundle()
            val frag = Fragment1()
            frag.arguments = bund
            bund.putString("count", counter1.toString())
            val ft = supportFragmentManager.beginTransaction()
            ft.replace(R.id.fcv, frag)
            ft.commit()
        }

        findViewById<Button>(R.id.b2).setOnClickListener {
            counter2++
            val bund1 = Bundle()
            val frag1 = Fragment2()
            frag1.arguments = bund1
            bund1.putString("count1", counter2.toString())
            val ft1 = supportFragmentManager.beginTransaction()
            ft1.replace(R.id.fcv, frag1)
            ft1.commit()
        }
    }
}


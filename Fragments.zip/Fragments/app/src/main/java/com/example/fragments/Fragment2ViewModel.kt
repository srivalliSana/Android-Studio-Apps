package com.example.fragments

import androidx.lifecycle.ViewModel

class Fragment2ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
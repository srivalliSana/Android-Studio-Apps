package com.example.activityfunctionsflow

import  android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        Log.d("ActivityLog","onCreate() called")
    }
    override  fun onStart(){
        super.onStart()
        Log.d("ActivityLog","onStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d("ActivityLog","onResume() called")
    }

    override fun onPause() {
        super.onPause()
        Log.d("ActivityLog","onPause() called")

    }

    override fun onStop() {
        super.onStop()
        Log.d("ActivityLog","onStop() called")
    }



    override fun onRestart() {
        super.onRestart()
        Log.d("ActivityLog","onRestart() called")
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.d("ActivityLog","onDestroy() called")
    }

}
package com.example.uicomponentdemos

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ListView
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener{
    private lateinit var img_view: ImageView
    private lateinit var fl: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val img_view = findViewById<ImageView>(R.id.imageView5)
        val cb1 = findViewById<CheckBox>(R.id.checkBox3)
        val cb2 = findViewById<CheckBox>(R.id.checkBox4)
        val cb3 = findViewById<CheckBox>(R.id.checkBox5)
        val cb4 = findViewById<CheckBox>(R.id.checkBox6)
        val cb5 = findViewById<CheckBox>(R.id.checkBox7)
        val cb6 = findViewById<CheckBox>(R.id.checkBox8)
        val cb7 = findViewById<CheckBox>(R.id.checkBox9)
        val cb8 = findViewById<CheckBox>(R.id.checkBox10)
        val rb1 = findViewById<RadioButton>(R.id.rb1)
        val rb2 = findViewById<RadioButton>(R.id.rb2)
        val rb3= findViewById<RadioButton>(R.id.rb3)
        val rb4 = findViewById<RadioButton>(R.id.rb4)
        val rb5 = findViewById<RadioButton>(R.id.rb5)
        val rb6 = findViewById<RadioButton>(R.id.rb6)
        val rb7 = findViewById<RadioButton>(R.id.rb7)
        val rb8 = findViewById<RadioButton>(R.id.rb8)
        rb1.setOnClickListener {
            cb1.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(0)
            img_view.setImageResource(R.drawable.img1)
        }

        rb2.setOnClickListener {
            cb2.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(1)
            img_view.setImageResource(R.drawable.img2)
        }
        rb3.setOnClickListener {
            cb3.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(2)
            img_view.setImageResource(R.drawable.img3)
        }
        rb4.setOnClickListener {
            cb4.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(3)
            img_view.setImageResource(R.drawable.img4)
        }
        rb5.setOnClickListener {
            cb5.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(4)
            img_view.setImageResource(R.drawable.img5)
        }
        rb6.setOnClickListener {
            cb6.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(5)
            img_view.setImageResource(R.drawable.img6)
        }
        rb7.setOnClickListener {
            cb7.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(6)
            img_view.setImageResource(R.drawable.img7)
        }
        rb8.setOnClickListener {
            cb8.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(7)
            img_view.setImageResource(R.drawable.img8)
        }
        fun uncheckAllCheckBoxes() {
            cb1.isChecked = false
            cb2.isChecked = false
            cb3.isChecked = false
            cb4.isChecked = false
            cb5.isChecked = false
            cb6.isChecked = false
            cb7.isChecked = false
            cb8.isChecked = false
        }
        cb1.setOnClickListener {
            rb1.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(0)
            uncheckAllCheckBoxes()
            cb1.isChecked = true
            if (cb1.isChecked) {
                img_view.setImageResource(R.drawable.img1)
            }
        }

        cb2.setOnClickListener {
            rb2.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(1)
            uncheckAllCheckBoxes()
            cb2.isChecked = true
            if (cb2.isChecked) {
                img_view.setImageResource(R.drawable.img2)
            }
        }
        cb3.setOnClickListener {
            rb3.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(2)
            uncheckAllCheckBoxes()
            cb3.isChecked = true
            if (cb3.isChecked) {
                img_view.setImageResource(R.drawable.img3)
            }
        }
        cb4.setOnClickListener {
            rb4.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(3)
            uncheckAllCheckBoxes()
            cb4.isChecked = true
            if (cb4.isChecked) {
                img_view.setImageResource(R.drawable.img4)
            }
        }

        cb5.setOnClickListener {
            rb5.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(4) // Select Floor Plan 5
            uncheckAllCheckBoxes()
            cb5.isChecked = true
            if (cb5.isChecked) {
                img_view.setImageResource(R.drawable.img5)
            }
        }
        cb6.setOnClickListener {
            rb6.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(5)
            uncheckAllCheckBoxes()
            cb6.isChecked = true
            if (cb6.isChecked) {
                img_view.setImageResource(R.drawable.img6)
            }
        }
        cb7.setOnClickListener {
            rb7.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(6)
            uncheckAllCheckBoxes()
            cb7.isChecked = true
            if (cb7.isChecked) {
                img_view.setImageResource(R.drawable.img7)
            }
        }
        cb8.setOnClickListener {
            rb8.isChecked = true
            val spinner = findViewById<Spinner>(R.id.spinner)
            spinner.setSelection(7)
            uncheckAllCheckBoxes()
            cb8.isChecked = true
            if (cb8.isChecked) {
                img_view.setImageResource(R.drawable.img8)
            }
        }
        val flrList = arrayOf("Floor Plan 1", "Floor Plan 2", "Floor Plan 3", "Floor Plan 4", "Floor Plan 5", "Floor Plan 6", "Floor Plan 7", "Floor Plan 8")
        val flr_aa = ArrayAdapter(this, android.R.layout.simple_spinner_item, flrList)
        flr_aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        val ps = findViewById<Spinner>(R.id.spinner)
        ps.adapter = flr_aa
        ps.onItemSelectedListener = this

        img_view.setImageResource(0)
        fl = findViewById(R.id.pl)
        val flListAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, flrList)
        fl.adapter = flListAdapter
    }
    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val img_view = findViewById<ImageView>(R.id.imageView5)
        when (position) {
            0 -> {
                img_view.setImageResource(R.drawable.img1)
                Toast.makeText(this, "Floor Plan 1 selected", Toast.LENGTH_SHORT).show()
            }
            1 -> {
                img_view.setImageResource(R.drawable.img2)
                Toast.makeText(this, "Floor Plan 2 selected", Toast.LENGTH_SHORT).show()
            }
            2 -> {
                img_view.setImageResource(R.drawable.img3)
                Toast.makeText(this, "Floor Plan 3 selected", Toast.LENGTH_SHORT).show()
            }
             3-> {
                img_view.setImageResource(R.drawable.img4)
                Toast.makeText(this, "Floor Plan 4 selected", Toast.LENGTH_SHORT).show()
            }
            4 -> {
                img_view.setImageResource(R.drawable.img5)
                Toast.makeText(this, "Floor Plan 5 selected", Toast.LENGTH_SHORT).show()
            }
            5 -> {
                img_view.setImageResource(R.drawable.img6)
                Toast.makeText(this, "Floor Plan 6 selected", Toast.LENGTH_SHORT).show()
            }
            6 -> {
                img_view.setImageResource(R.drawable.img7)
                Toast.makeText(this, "Floor Plan 7 selected", Toast.LENGTH_SHORT).show()
            }
            7 -> {
                img_view.setImageResource(R.drawable.img8)
                Toast.makeText(this, "Floor Plan 8 selected", Toast.LENGTH_SHORT).show()
            }
        }

    }



    override fun onNothingSelected(p0: AdapterView<*>?) {
        TODO("Not yet implemented")
    }

}
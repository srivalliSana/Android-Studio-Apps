package com.example.caluculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var resultTextView: TextView
    private lateinit var valuePlaceTextView: TextView
    private var currentExpression = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Initialize TextViews
        resultTextView = findViewById(R.id.resultTextView)
        valuePlaceTextView = findViewById(R.id.ValuePlace)

        // Initialize buttons
        val buttonIds = listOf(
            R.id.ACButton, R.id.ClearButton, R.id.BracketButtonn, R.id.DivButton,
            R.id.Button7, R.id.Button8, R.id.Button9, R.id.MulButton,
            R.id.Button4, R.id.Button5, R.id.Button6, R.id.SubButton,
            R.id.Button1, R.id.Button2, R.id.Button3, R.id.AddButton,
            R.id.ModulusButton, R.id.Button0, R.id.FullStopButton, R.id.EqualButton
        )

        buttonIds.forEach { id ->
            findViewById<Button>(id).setOnClickListener { handleButtonClick(it as Button) }
        }
    }
    private fun handleButtonClick(button: Button) {
        val buttonText = button.text.toString()

        when (buttonText) {
            "AC" -> clearAll()
            "C" -> clearLastCharacter()
            "=" -> calculateResult()
            else -> appendToExpression(buttonText)
        }
    }

    private fun clearAll() {
        currentExpression = ""
        updateValuePlace("0")
        updateResultView("0")
    }

    private fun clearLastCharacter() {
        if (currentExpression.isNotEmpty()) {
            currentExpression = currentExpression.dropLast(1)
            updateValuePlace(currentExpression.ifEmpty { "0" })
            if (currentExpression.isNotEmpty()) {
                calculateResultPreview()
            } else {
                updateResultView("0")
            }
        }
    }

    private fun appendToExpression(value: String) {
        if (isOperator(value) && (currentExpression.isEmpty() || isOperator(currentExpression.last().toString()))) {
            // Avoid appending multiple operators
            currentExpression = currentExpression.dropLast(1) + value
        } else {
            currentExpression += value
        }
        updateValuePlace(currentExpression)
        calculateResultPreview()
    }

    private fun calculateResultPreview() {
        try {
            val sanitizedExpression = sanitizeExpression(currentExpression)
            val result = evaluateExpression(sanitizedExpression)
            updateResultView(result.toString())
        } catch (e: Exception) {
            updateResultView("")
        }
    }

    private fun calculateResult() {
        try {
            val sanitizedExpression = sanitizeExpression(currentExpression)
            val result = evaluateExpression(sanitizedExpression)
            updateResultView(result.toString())
            currentExpression = result.toString()
            updateValuePlace(currentExpression)
        } catch (e: Exception) {
            updateResultView("Error")
        }
    }

    private fun sanitizeExpression(expression: String): String {
        return expression
            .replace("÷", "/")
            .replace("×", "*")
            .replace("%", "/100") // Handle modulus
            .replace("[^0-9+\\-*/().]".toRegex(), "") // Remove invalid characters
    }

    private fun updateResultView(value: String) {
        resultTextView.text = value
    }

    private fun updateValuePlace(value: String) {
        valuePlaceTextView.text = value
    }

    private fun evaluateExpression(expression: String): Double {
        return ExpressionEvaluator().evaluate(expression)
    }

    private fun isOperator(char: String): Boolean {
        return char in listOf("+", "-", "×", "÷", "*", "/")
    }
}

class ExpressionEvaluator {
    fun evaluate(expression: String): Double {
        return object : Any() {
            var pos = -1
            var ch: Char = ' '

            fun nextChar() {
                pos++
                ch = if (pos < expression.length) expression[pos] else '\u0000'
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < expression.length) throw RuntimeException("Unexpected: $ch")
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    when (ch) {
                        '+' -> {
                            nextChar()
                            x += parseTerm()
                        }
                        '-' -> {
                            nextChar()
                            x -= parseTerm()
                        }
                        else -> return x
                    }
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    when (ch) {
                        '*' -> {
                            nextChar()
                            x *= parseFactor()
                        }
                        '/' -> {
                            nextChar()
                            x /= parseFactor()
                        }
                        else -> return x
                    }
                }
            }

            fun parseFactor(): Double {
                if (ch == '+') {
                    nextChar()
                    return parseFactor()
                }
                if (ch == '-') {
                    nextChar()
                    return -parseFactor()
                }

                var x: Double
                val startPos = pos
                if (ch.isDigit() || ch == '.') {
                    while (ch.isDigit() || ch == '.') nextChar()
                    x = expression.substring(startPos, pos).toDouble()
                } else if (ch == '(') {
                    nextChar()
                    x = parseExpression()
                    if (ch == ')') nextChar()
                } else {
                    throw RuntimeException("Unexpected: $ch")
                }

                return x
            }
        }.parse()
    }
}
package com.example.uicomponentdemo

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ListView
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    private lateinit var img_view: ImageView
    private lateinit var fl: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val img_view = findViewById<ImageView>(R.id.imageView5)
        val rb1 = findViewById<RadioButton>(R.id.rb1)
        rb1.setOnClickListener {
            img_view.setImageResource(R.drawable.img1)
        }

        val rb2 = findViewById<RadioButton>(R.id.rb2)
        rb2.setOnClickListener {
            img_view.setImageResource(R.drawable.img2)
        }

        val cb1 = findViewById<CheckBox>(R.id.checkBox3)
        cb1.setOnClickListener {
            if (cb1.isChecked) {
                img_view.setImageResource(R.drawable.img1)
            }
        }

        val cb2 = findViewById<CheckBox>(R.id.checkBox4)
        cb2.setOnClickListener {
            if (cb2.isChecked) {
                img_view.setImageResource(R.drawable.img2)
            }
        }

        val flrList = arrayOf("Floor Plan 1", "Floor Plan 2")
        val flr_aa = ArrayAdapter(this, android.R.layout.simple_spinner_item, flrList)
        flr_aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        val ps = findViewById<Spinner>(R.id.spinner)
        ps.adapter = flr_aa
        ps.onItemSelectedListener = this

        img_view.setImageResource(0)
        fl = findViewById(R.id.pl)
        val flListAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, flrList)
        fl.adapter = flListAdapter
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val img_view = findViewById<ImageView>(R.id.imageView5)
        when (position) {
            0 -> {
                img_view.setImageResource(R.drawable.img1)
                Toast.makeText(this, "Floor Plan 1 selected", Toast.LENGTH_SHORT).show()
            }
            1 -> {
                img_view.setImageResource(R.drawable.img2)
                Toast.makeText(this, "Floor Plan 2 selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}



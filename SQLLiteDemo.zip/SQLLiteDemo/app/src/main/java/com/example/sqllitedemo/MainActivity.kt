package com.example.sqllitedemo

import android.os.Bundle
import android.os.Environment
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var nameInput: EditText
    private lateinit var messageInput: EditText
    private lateinit var fileNameInput: EditText
    private lateinit var saveButton: Button
    private lateinit var saveToFileButton: Button
    private lateinit var nameSpinner: Spinner
    private lateinit var messageList: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)
        nameInput = findViewById(R.id.nameInput)
        messageInput = findViewById(R.id.messageInput)
        fileNameInput = findViewById(R.id.fileNameInput)
        saveButton = findViewById(R.id.saveButton)
        saveToFileButton = findViewById(R.id.saveToFileButton)
        nameSpinner = findViewById(R.id.nameSpinner)
        messageList = findViewById(R.id.messageList)

        loadFilesFromStorage()

        saveButton.setOnClickListener {
            val name = nameInput.text.toString()
            val message = messageInput.text.toString()
            if (name.isNotEmpty() && message.isNotEmpty()) {
                fileNameInput.visibility = android.view.View.VISIBLE
                saveToFileButton.visibility = android.view.View.VISIBLE
            } else {
                Toast.makeText(this, "Enter valid data!", Toast.LENGTH_SHORT).show()
            }
        }

        saveToFileButton.setOnClickListener {
            val fileName = fileNameInput.text.toString()
            val message = messageInput.text.toString()
            if (fileName.isNotEmpty()) {
                saveMessageToFile(fileName, message)
            } else {
                Toast.makeText(this, "Enter a file name", Toast.LENGTH_SHORT).show()
            }
        }

        nameSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selectedFile = parent?.getItemAtPosition(position).toString()
                loadMessagesFromFile(selectedFile)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun saveMessageToFile(fileName: String, message: String) {
        val directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val file = File(directory, "$fileName.txt")
        try {
            FileOutputStream(file, true).use { output ->
                output.write(("$message\n").toByteArray())
            }
            Toast.makeText(this, "File saved: ${file.absolutePath}", Toast.LENGTH_SHORT).show()
            loadFilesFromStorage()
        } catch (e: IOException) {
            Toast.makeText(this, "Failed to save file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadFilesFromStorage() {
        val directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val files = directory.listFiles { file -> file.extension == "txt" }?.map { it.nameWithoutExtension } ?: emptyList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, files)
        nameSpinner.adapter = adapter
    }

    private fun loadMessagesFromFile(fileName: String) {
        val directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val file = File(directory, "$fileName.txt")
        if (file.exists()) {
            val messages = file.readLines()
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, messages)
            messageList.adapter = adapter
        } else {
            messageList.adapter = null
            Toast.makeText(this, "No messages found", Toast.LENGTH_SHORT).show()
        }
    }
}
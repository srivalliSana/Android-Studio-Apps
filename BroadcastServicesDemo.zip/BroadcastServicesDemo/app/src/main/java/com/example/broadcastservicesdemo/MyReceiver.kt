package com.example.broadcastservicesdemo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MyReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val currentState = intent.getBooleanExtra("state", false)
        if (currentState) {
            Toast.makeText(context, "Airplane mode activated", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "Airplane mode deactivated", Toast.LENGTH_LONG).show()
        }
    }

}
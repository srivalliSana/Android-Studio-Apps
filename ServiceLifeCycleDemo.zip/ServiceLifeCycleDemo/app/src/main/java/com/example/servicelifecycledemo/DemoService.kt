package com.example.servicelifecycledemo

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import java.util.Timer
import java.util.TimerTask

class DemoService : Service() {

    private var timer = Timer()
    private var counter = 0
    private var isStarted = false

    override fun onBind(intent: Intent): IBinder {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        if(isStarted){
            Log.d("Service Log", "Service already running")
        }else {
            isStarted = true
            timer.schedule(object : TimerTask() {
                override fun run() {
                    counter++
                    Log.d("Service Log", "$counter secs passed since the service started")
                }
            }, 0, 1000)
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        timer.cancel()
        isStarted = false
        Log.d("Service Log", "Service stopped")
    }
}